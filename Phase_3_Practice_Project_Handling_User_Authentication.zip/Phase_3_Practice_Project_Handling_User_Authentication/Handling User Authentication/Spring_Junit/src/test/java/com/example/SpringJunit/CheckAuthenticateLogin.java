package com.example.SpringJunit;


import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

@RunWith(JUnitPlatform.class)
public class CheckAuthenticateLogin {
	
	Authenticate auth;
	
	
	
	@BeforeEach
	void initEach()
	{
		System.out.println("\nObject of Authenticate class Created");
		auth=new Authenticate();
	}
	
	@Test
	@DisplayName("TestCase 1")
	void test1_authenticate()
	{
		String name="Sai";
		String pass="Sai@123";
		
		String expected="Login Successfull";
		String actual=auth.authenticate_login(name, pass);
		Assertions.assertEquals(expected, actual);
		System.out.println("\nTestCase 1: "+"Passed");
		
	}
	
	@Test
	@DisplayName("TestCase 2")
	void test2_authenticate()
	{

		String name="Sai";
		String pass="Sai123";
		
		String expected="Login Failed";
		String actual=auth.authenticate_login(name, pass);
		Assertions.assertEquals(expected, actual);
		System.out.println("\nTestCase 2: "+"Passed");
	}
	
	@Test
	@DisplayName("TestCase 3")
	void test3_authenticate()
	{

		String name="Harry";
		String pass="Harry007";
		
		String expected="Login Successfull";
		String actual=auth.authenticate_login1(name, pass);
		Assertions.assertEquals(expected, actual);
		System.out.println("\nTestCase 3: "+"Passed");
	}
	

	@Test
	@DisplayName("TestCase 4")
	void test4_authenticate()
	{

		String name="Jonas";
		String pass="Jonas22";
		
		String expected="Login Failed";
		String actual=auth.authenticate_login1(name, pass);
		Assertions.assertEquals(expected, actual);
		System.out.println("\nTestCase 4: "+"Passed");
	}
	
	
	
	
	
	
	

}

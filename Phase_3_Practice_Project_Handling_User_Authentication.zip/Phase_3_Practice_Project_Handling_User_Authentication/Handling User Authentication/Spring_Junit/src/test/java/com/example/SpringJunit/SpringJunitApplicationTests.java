package com.example.SpringJunit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJunitApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.SpringJunit;


public class Authenticate {
	
	
	public String authenticate_login(String user, String password)
	{
		
		if((user.equals("Abhi"))&&(password.equals("Abhi@123")))
		{
			return "Login Successfull";
		}
		return "Login Failed";
	}
	
	public String authenticate_login1(String user, String password)
	{
		
		if((user.equals("Harry"))&&(password.equals("Harry007")))
		{
			return "Login Successfull";
		}
		return "Login Failed";
	}
	
	
	
	

}

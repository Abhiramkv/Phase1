package phase1Project;

public class VirtualKeyRepositories {

	public static void main(String[] args) {
		
		FileOperations.createMainFolderIfNotExist("main");
		
		FileMenuOption.printWelcomeScreen("LockedMe.com", "Abhiram");
		
		FileHandleOption.handleWelcomeScreenInput();

	}

}

package assistedProjects3;

public class Double {

	Node head; 

	static class Node {
		int data;
		Node next;
		Node prev;

		Node(int d) {
			prev = null;
			data = d;
			next = null;
		}
	}

	public static Double insert(Double list, int data) {
		
		Node new_node=new Node(data);
		if (list.head == null) {
			list.head = new_node;
		}
		else
			
			{
				Node last;
				
				for(last=list.head;last.next!=null;last=last.next){}
				last.next=new_node;
				new_node.prev=last;
			}
		return list;

	}

	public static void printList(Double list){
		
		for(Node last=list.head;last!=null;last=last.next){
			
			System.out.print(last.data+" ");
			
		}
		System.out.println();
	}
		
	

	public static void printListReverse(Double list) {
		Node last = list.head;
		System.out.print("Reverse ");
		
		for (last=list.head;last.next != null;last = last.next) {}


		for (;last != null;last = last.prev) {
			
			System.out.print(last.data + " ");
			
			
		}
		
	}
	public static void main(String[] args) {
		
		Double list = new Double();
		
		list = insert(list, 1);
		list = insert(list, 2);
		list = insert(list, 3);
		list = insert(list, 4);
		list = insert(list, 5);
		list = insert(list, 6);
		list = insert(list, 7);
		list = insert(list, 8);
		
		printList(list);
		
		printListReverse(list);
	}

}

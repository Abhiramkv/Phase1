package assistedProjects3;

public class ArrayRotation {
	
	public void rotate(int arr[], int d, int n) {
		
		int temp[] = new int[d];
		for(int i=0;i<d;i++) {
			temp[i]=arr[i];
		}
		
		for(int i=d;i<n;i++) {
			arr[i-d] = arr[i];
		}
		
		for(int i=0;i<d;i++) {
			arr[i+n-d]=temp[i];
		}
		}
	
	public void print(int arr[],int n) {
		
		for(int i=0;i<n;i++)
			System.out.println(arr[i]);
	}

	public static void main(String[] args) {
		
		ArrayRotation ar = new ArrayRotation();
		int array[]={1,2,3,4,5,6,7,8};
		
		ar.rotate(array,3,array.length);
		ar.print(array, array.length);

	}

}

package assistedProjects3;
import java.util.*;

public class FourthSmallest {

	public static void main(String[] args)
    {
        int[] arr = { 5,9,4,6,8,1,2,7,3 };
        int n = arr.length;
        int k = 4;
           
          k--;
           
        Set<Integer> s = new TreeSet<Integer>();
       
          
        for(int i=0;i<n;i++)
          s.add(arr[i]);
         
          
        Iterator<Integer> itr = s.iterator();
       
        while(k>0)
        {
          itr.next();
          k--;
        }
        System.out.println(itr.next());
    }

}

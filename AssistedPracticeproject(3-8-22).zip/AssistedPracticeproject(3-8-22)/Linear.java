package assisted;

import java.util.Scanner;

public class Linear {

	public static void main(String[] args) {
		
		int arr[] = {15,45,1,7,18,10,17,99,8,93};
		int key;
		while(true) {
		System.out.println("enter the value to be searched");
		Scanner sc = new Scanner(System.in);
		key = sc.nextInt();
		
		boolean found = false;
		for(int val:arr)
			if(val==key) {
				found = true;
				break;
			}
		if(found==true)
			System.out.println("value found");
		else
			System.out.println("value not found");
		}

	}

}

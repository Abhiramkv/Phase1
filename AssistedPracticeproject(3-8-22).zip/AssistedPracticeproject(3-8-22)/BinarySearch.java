package assisted;

import java.util.Arrays;

public class BinarySearch {
	
	public static boolean BinarySearch(int arr[],int key) {
		boolean ans=false;
		int st=0;
		int end=arr.length-1;
		int mid;
		while(st<=end) {
			mid=(st+end)/2;
			if(arr[mid]==key) {
				ans=true;
				break;
			}
			else if(arr[mid]>key) {
				
				end=mid-1;
			}
			else {
				st=mid+1;
			}
		}
		return ans;
		
		
		
	}

	public static void main(String[] args) {
		
		int A[]= {5,8,1,6,9,7,2};
		Selection.Selection(A);
		System.out.println(Arrays.toString(A));
		boolean ans=BinarySearch(A,8);
		if(ans) {
			System.out.println("key found");
		}
		else {
			System.out.println("not found");
		}
		
	}

}

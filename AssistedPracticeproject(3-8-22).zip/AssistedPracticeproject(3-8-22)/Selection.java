package assisted;

import java.util.Arrays;

public class Selection {
	
	static void Selection(int arr[]) {
		
		for(int i=0;i<arr.length;i++) {
			for(int j=i+1;j<arr.length;j++) {
				if(arr[i]>arr[j]) {
				int temp = arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
				}
			}
		}
		
	}

	public static void main(String[] args) {
		
		int A[]= {5,8,3,1,9,7,6};
		Selection(A);
		System.out.println(Arrays.toString(A));
	}

}

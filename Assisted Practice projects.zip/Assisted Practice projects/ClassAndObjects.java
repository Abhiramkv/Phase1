package practice2;

public class ClassAndObjects {
	
	 String name; 
	 String state; 
	 int age; 
	 
	 public ClassAndObjects(String name, String state, int age) 
	    { 
	        this.name = name; 
	        this.state = state; 
	        this.age = age; 
	       
	    } 
	    public String getName() 
	    { 
	        return name; 
	    } 
	    public String getstate() 
	    { 
	        return state; 
	    } 
	    public int getAge() 
	    { 
	        return age; 
	    } 
	   
	    @Override
	    public String toString() 
	    { 
	        return("Name: "+ this.getName()+ " State: " + this.getstate()+" age:"+this.getAge()); 
	    } 


	public static void main(String[] args) {
		
        ClassAndObjects person = new  ClassAndObjects("ABC","TN", 22); 
        System.out.println(person.toString()); 

		

	}

}

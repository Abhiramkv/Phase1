package package1;

public class Project2 {

	protected void display()
    {
        System.out.println("hello everyone");
    }
}

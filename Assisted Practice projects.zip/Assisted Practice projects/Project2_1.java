package package2;

import package1.Project2;

public class Project2_1 extends Project2{

	public static void main(String[] args) {
		Project2_1 obj = new Project2_1();
	    obj.display();
		

	}

}

import java.util.*;
public class Project5 {

	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();
        list.add("hello");
        list.add("everyone");
        list.add("welcome");
        list.add("tojava");
 
        System.out.println(list);
        
        Iterator<String> itr= list.iterator();
        while(itr.hasNext()) {
        	System.out.println(itr.next());
        }
	}

}

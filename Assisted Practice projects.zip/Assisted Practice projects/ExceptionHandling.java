package practice2;

import java.util.Scanner;

class BankValueException extends Exception {
	@Override
	public String toString() {
		return "Balance not sufficient";
	}
}

public class ExceptionHandling {
	
	static void validate() throws BankValueException {
		Scanner a = new Scanner(System.in);
		System.out.println("enter the amount");
		int amount = a.nextInt();
		if (amount > 10000) {
			throw new BankValueException();
		} else {
			System.out.println("Amount deducted");
		}
	}

	public static void main(String[] args) {
		try {
			validate();
		} catch (BankValueException e) {
			System.out.println(e);
		}

	}

}

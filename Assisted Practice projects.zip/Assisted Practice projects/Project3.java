
public class Project3 {
	//call by value
	public int addition(int num1, int num2) {
		
		int sum = num1+num2;
		return sum;
	}

	public static void main(String[] args) {
		
		Project3 s = new Project3();
		int sum = s.addition(20, 40);
		System.out.println("Sum is "+sum);
		
	}

}

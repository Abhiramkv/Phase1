import java.util.regex.*;
public class Project10 {

	public static void main(String[] args) {
		
		System.out.println(Pattern.matches("HelloEveryone", "HelloEveryone"));
		System.out.println(Pattern.matches("HelloEveryone", "HelloEvery"));
		
		Pattern p = Pattern.compile("hello");
		
		Matcher m = p.matcher("helloeveryone Hello");
		
		while(m.find())
			System.out.println("pattern found from "+ m.start()+ "-" +(m.end()-1));

	}
}



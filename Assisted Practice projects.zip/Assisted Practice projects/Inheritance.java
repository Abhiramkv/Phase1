package practice2;

class Animal{ 
	
	void eat(){
		System.out.println("eating");
		}  
	
	}  

class Dog extends Animal{  

	void dog(){
		System.out.println("eats bone");}  
	}  

class Cat extends Animal{  
	
	void cat(){
		System.out.println("drinks milk");
		}  
	}  

public class Inheritance{  

public static void main(String args[]){ 
	
	
	Dog d = new Dog();
	Cat c=new Cat();
	d.eat();
	d.dog();
	c.cat();  
	  
  
}

} 
package practice2;

class Mythread extends Thread{
	
	public void run(){
		System.out.println(this.getId()+" thread");
		
	}
	
}

public class ExtendThread {

	public static void main(String[] args) {
		
		Mythread th=new Mythread();
		th.setPriority(2);
		th.start();
		
		System.out.println("Main Method");
	}

}

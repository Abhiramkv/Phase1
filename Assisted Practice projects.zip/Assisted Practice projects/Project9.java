
public class Project9 {

	public static void main(String[] args) {
		
		int array[] = new int[] {1,2,3,4,5};
		int sum=0;
		for(int i=0;i<=array.length;i++) {
			sum=sum+i;
		}
		System.out.println("sum is "+sum);
		
		int array2[][]= {
				{1,2,3,4},
				{2,5,8},
				{9},
		};
		System.out.println("length of row 1: "+array2[0].length);
		System.out.println("length of row 2: "+array2[1].length);
		System.out.println("length of row 3: "+array2[2].length);
		}
	}



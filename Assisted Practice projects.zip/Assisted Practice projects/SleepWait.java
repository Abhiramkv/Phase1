package practice2;

public class SleepWait {

	private static Object LOCK = new Object();
	 
	public static void main(String[] args)throws InterruptedException {
	  
	    Thread.sleep(5000);
	   
	    System.out.println(Thread.currentThread().getName() +" sleeping for 5 seconds");
	  
	    synchronized (LOCK)
	    {
	        LOCK.wait(1000);
	       
	        System.out.println(LOCK + "waiting for 1 second");
	    }
	}

}

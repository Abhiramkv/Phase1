
public class Project7 {
	
	int num1,num2;
	int sum=0;
	
	public int add(int num1,int num2) {
		this.num1=num1;
		this.num2=num2;
		sum=this.num1+this.num2;
		return sum;
	}
	class Inner{
		void print() {
			System.out.println("sum: "+sum);
		}
	}
	public static void main(String[] args) {
		
		Project7 obj = new Project7();
		Project7.Inner in = obj.new Inner();
		obj.add(20,30);
		in.print();
	}
	
	
	
	


}
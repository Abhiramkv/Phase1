
public class Project1 {

	public static void main(String[] args) {
		
		System.out.println("Implicit type casting");
		
		int a = 150;
		long b = a;
		float c = b;
		
		System.out.println("value of int " +  a);
		System.out.println("value of long " +  b);
		System.out.println("value of float " +  c);
		
		char d = 'a';
		int e = d;
		 
		System.out.println("value of character " +  d);
		System.out.println("value of int " +  e);
		
		System.out.println("Explicit type casting");
		
		double f = 250.52;
		int g = (int)f;
		long h = (long)g;
		
		System.out.println("value of double " +f);
		System.out.println("value of int " +g);
		System.out.println("value of int " +h);

	}

}

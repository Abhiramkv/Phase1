package practice2;

import java.util.Scanner;

class VotingAgeException extends Exception {
	static public boolean isEligible(int age) {
		if (age > 18)
			return true;
		else
			return false;
	}
}

public class Throws {

	public static void main(String[] args) throws VotingAgeException {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter age");
		int age=sc.nextInt();
		
		if(VotingAgeException.isEligible(age))
			System.out.println("You are Eligible for voting");
		
		else
			throw new VotingAgeException();
		
	}

}

package practice2;

class thread implements Runnable{
	
	

	@Override
	public void run() {
		
		System.out.println("This is a thread");
		
	}
	
}

public class RunnableExample {

	public static void main(String[] args) {
		
		System.out.println("Main starts");
		
		Thread t=new Thread(new thread());
		t.start();
		
		System.out.println("Main stops");
		

	}

}


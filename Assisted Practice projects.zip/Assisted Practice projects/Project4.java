
public class Project4  {
	String name;
	int age;
	char section;
	char gender;
	int sub1,sub2,sub3;
	float total;
	
	
	Project4(String name,int age,char section,char gender,int sub1,int sub2,int sub3)
	{
		this.name=name;
		this.age=age;
		this.section=section;
		this.gender=gender;
		this.sub1=sub1;
		this.sub2=sub2;
		this.sub3=sub3;
		total=(sub1+sub2+sub3);
		System.out.println("Total marks obtained by student: "+total);
		float percentage=total/300*100;
		System.out.println("Percentage obtained by student: "+percentage);
	}
	
	Project4(String name,int age,char section,char gender,int sub2,int sub3)
	{
		this.name=name;
		this.age=age;
		this.section=section;
		this.gender=gender;
		this.sub2=sub2;
		this.sub3=sub3;
		total=(sub1+sub2+sub3);
		System.out.println("\nTotal marks obtained by student"+" "+total);
		float per=((total/300)*100);
		System.out.println("\nPercentage obtained by student"+" "+per);
	}
	void dislay()
	{
		System.out.println("Student name: "+name);
		System.out.println("Student Age:"+" "+age);
		System.out.println("Student section: "+" "+section);
		System.out.println("Student Gender: "+" "+gender);
		System.out.println("Subject 1 marks: "+" "+sub1);
		System.out.println("Subject 2 marks: "+" "+sub2);
		System.out.println("Subject 3 marks: "+" "+sub3);
	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Project4 s1=new Project4("Harry",20,'A','M',81,78,75);
		Project4 s2=new Project4("Janu",22,'B','F',90,97);
		Project4 s3=new Project4("Sai",21,'C','M',89,67);
		Project4 s4=new Project4("John",25,'D','M',70,88,68);
	    s1.dislay();
	    
	    s2.dislay();
	    
	    s3.dislay();
	    
	    s4.dislay();
	    
		

	}

}


public class Project8 {

	public static void main(String[] args) {
		
		String str = new String("Hello world");
		System.out.println(str);
		
		System.out.println(str.length());
		
		StringBuffer s = new StringBuffer("Welcome");
		s.append(" everyone");
		System.out.println("String buffer: "+s);
		
		
		StringBuilder s1 = new StringBuilder("hello");
		s1.append(" welcome to java programming");
		System.out.println("String builder: "+s1);
		

	}

}

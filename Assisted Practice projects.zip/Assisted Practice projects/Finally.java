package practice2;

public class Finally {

	public static void main(String[] args) {
		
		try{
			
			System.out.println(5/0);
		}
		catch(ArithmeticException e){
			e.printStackTrace();
			
		}
		finally{
			System.out.println("End of program");
		}
		System.out.println("Hello!");

	}

}

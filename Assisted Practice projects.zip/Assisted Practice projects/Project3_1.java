
public class Project3_1 {
	
	public void addition(int num1, int num2) {
		System.out.println("Sum is "+(num1+num2));
	}
	
	public void multiplication(int a, int b, int c) {
		System.out.println("product is "+(a*b*c));
	}
	

	public static void main(String[] args) {
		
		Project3_1 res = new Project3_1();
		res.addition(15, 30);
		res.multiplication(5,8,3);
		

	}

}

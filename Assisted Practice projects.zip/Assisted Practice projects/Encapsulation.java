package practice2;

class Encapsulate{ 
    private String Name; 
    private String State; 
    private int Age;
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	
    
}


public class Encapsulation {

	public static void main(String[] args) {
		
		Encapsulate obj = new Encapsulate(); 
        obj.setName("ABC"); 
        obj.setAge(22); 
        obj.setState("TN"); 
        System.out.println("My name: " + obj.getName()); 
        System.out.println("My age: " + obj.getAge()); 
        System.out.println("My State: " + obj.getState());      


	}

}

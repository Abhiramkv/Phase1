package practice2;

abstract class birds{
	abstract void fly();
}

class parrot extends birds{
	
	public void fly() {
		System.out.println("parrot can fly");
	}
}

class penquin extends birds{
	
	public void fly() {
		System.out.println("penquin cannot fly");
	}
}

public class Abstraction {

	public static void main(String[] args) {
		
		parrot b1 = new parrot();
		b1.fly();
		penquin b2 = new penquin();
		b2.fly();

	}

}

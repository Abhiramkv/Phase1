package practice2;



public class TryAndCatch {
	public static void main(String[] args) {
		System.out.println("hello");
			try{
			System.out.println(2/0);
			
			}
			catch(ArithmeticException e){
				e.printStackTrace();
				//System.out.println("division by 0 is not possible");
			}
			System.out.println("everyone");
	}

}

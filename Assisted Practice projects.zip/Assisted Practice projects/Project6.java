import java.util.*;
public class Project6 {

	public static void main(String[] args) {
		
		HashMap<String,Integer> hm =new HashMap<String,Integer>();
		hm.put("one",1);
		hm.put("two",2);
		hm.put("three",3);
		
		System.out.println("hashmap elements are:");
		for(Map.Entry E:hm.entrySet()) {
			System.out.println(E.getKey()+" "+E.getValue());
		}
		
		

	}

}
